var express=require('express');
var mongoose=require("mongoose");
var url=require('url');
var bodyparser=require('body-parser');
var app=express();

mongoose.connect("mongodb://127.0.0.1:27017/search");

doctor_schema= new mongoose.Schema({
    "doctor_name":String,
    "doctor_contact_no":Number,
    "doctor_email":String,
    "doctor_specialist":String
});

var doctorModel=mongoose.model("doctor",doctor_schema);

app.use(bodyparser.urlencoded({extended:true}));

app.get("/", async function(req,res)
{
    var doct_list= await doctorModel.find();
    res.render("home.ejs",{"doct_list":doct_list});
});
app.get("/add",function(req,res)
{
    res.render("form.ejs");
});
app.post("/save_doctor",function(req,res)
{
   var newData= new doctorModel(req.body);
   newData.save();
   res.redirect("/");
});

app.get("/search",async function(req,res){
   var urldata=url.parse(req.url,true).query;
   var data=(urldata.search_doctor);
   var search_doctor= await doctorModel.find({"doctor_name":data});
   res.render("search_doctor.ejs",{"search":search_doctor});
   
})
app.listen(1000);